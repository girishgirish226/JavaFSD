
public class TypeCastingDemo {

	public static void main(String[] args) {
		int num1 = 100;
        long num2 = num1;
        System.out.println("Implicit type casting from int to long: " + num2);

        float num3 = 3.14f;
        double num4 = num3;
        System.out.println("Implicit type casting from float to double: " + num4);

        double num5 = 1234.56;
        int num6 = (int) num5;
        System.out.println("Explicit type casting from double to int: " + num6);

        float num7 = 5.678f;
        int num8 = (int) num7;
        System.out.println("Explicit type casting from float to int: " + num8);

	}

}
