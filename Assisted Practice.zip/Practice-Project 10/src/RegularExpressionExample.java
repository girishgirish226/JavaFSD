import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class RegularExpressionExample {
	
	public static void main(String[] args) {
		String regex = "\\d{3}-\\d{3}-\\d{4}";
        Pattern pattern = Pattern.compile(regex);
        String text = "My phone number is 888-816-8378.";
        
        Matcher matcher = pattern.matcher(text);

        if (matcher.find()) {
            System.out.println("Found phone number: " + matcher.group());
        } else {
            System.out.println("No phone number found.");
        }

        String[] phoneNumbers = {
            "888-816-8378",
            "(888) 816-8378",
            "8888168378",
            "888-81-68378"
        };

        for (String phoneNumber : phoneNumbers) {
            matcher = pattern.matcher(phoneNumber);
            if (matcher.find()) {
                System.out.println(phoneNumber + " is a valid phone number.");
            } else {
                System.out.println(phoneNumber + " is not a valid phone number.");
            }
        }

	}

}
