
public class AccessModifiersExample {

	public static void main(String[] args) {
		Animal animal = new Animal();
        animal.name = "Dog";
        animal.setColor("Brown");

        System.out.println("Animal Name: " + animal.name);
        System.out.println("Animal Color: " + animal.getColor());
    }
}
class Animal {
    public String name; 
    private String color; 

    public void setColor(String color) { 
        this.color = color;
    }

    public String getColor() { 
        return color;

	}

}
