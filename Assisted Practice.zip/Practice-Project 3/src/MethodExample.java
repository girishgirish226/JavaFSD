
public class MethodExample {

	public static void main(String[] args) {
		int sum = add(2, 3);
        System.out.println("Sum of 2 and 3 is: " + sum);
        Rectangle rect = new Rectangle(3, 4);
        int area = rect.getArea();
        System.out.println("Area of rectangle with width " + rect.width + " and height " + rect.height + " is: " + area);
        String reversed = StringReverse.reverse("Hello World");
        System.out.println("Reversed string is: " + reversed);
    }
    public static int add(int a, int b) {
        return a + b;
    }
}

class Rectangle {
    public int width;
    public int height;

    public Rectangle(int width, int height) {
        this.width = width;
        this.height = height;
    }
    public int getArea() {
        return width * height;
    }
}

class StringReverse {
    public static String reverse(String str) {
        StringBuilder sb = new StringBuilder(str);
        return sb.reverse().toString();

	}

}
