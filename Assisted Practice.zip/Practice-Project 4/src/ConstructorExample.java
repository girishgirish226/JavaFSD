
public class ConstructorExample {
	public static void main(String[] args) {
		Person person1 = new Person();
        System.out.println("Person 1: " + person1.getName() + ", " + person1.getAge());
        Person person2 = new Person("John", 30);
        System.out.println("Person 2: " + person2.getName() + ", " + person2.getAge());
        Person person3 = new Person(person2);
        System.out.println("Person 3: " + person3.getName() + ", " + person3.getAge());
    }
}
class Person {
    private String name;
    private int age;
    public Person() {
        this.name = "Unknown";
        this.age = 0;
    }
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    public Person(Person person) {
        this.name = person.name;
        this.age = person.age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;

	}

}
