package collections;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
public class Collection {

	public static void main(String[] args) {
		List<String> stringList = new ArrayList<>();
        stringList.add("Java");
        stringList.add("Python");
        stringList.add("C++");
        stringList.add("JavaScript");

        System.out.println("List of strings:");
        for (String str : stringList) {
            System.out.println(str);
        }

        Set<Integer> intSet = new HashSet<>();
        intSet.add(10);
        intSet.add(20);
        intSet.add(30);
        intSet.add(20);

        System.out.println("\nSet of integers:");
        for (int num : intSet) {
            System.out.println(num);
        }

	}

}
