package maps;
import java.util.HashMap;
import java.util.Map;
public class MapExample {

	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<>();
        map.put("apple", 1);
        map.put("banana", 2);
        map.put("cherry", 3);
        System.out.println("HashMap: " + map);
        int value = map.get("banana");
        System.out.println("Value for key 'banana': " + value);
        boolean exists = map.containsKey("apple");
        System.out.println("Key 'apple' exists: " + exists);
        map.remove("cherry");
        System.out.println("HashMap after removing key 'cherry': " + map);
        System.out.println("Keys in HashMap:");
        for (String key : map.keySet()) {
            System.out.println(key);
        }
        System.out.println("Values in HashMap:");
        for (int val : map.values()) {
            System.out.println(val);
        }
        System.out.println("Key-Value pairs in HashMap:");
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            String key = entry.getKey();
            int val = entry.getValue();
            System.out.println(key + " => " + val);
        }

	}

}
