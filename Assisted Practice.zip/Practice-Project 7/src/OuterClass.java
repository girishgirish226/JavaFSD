public class OuterClass {
    private int outerInt = 10;

    public void outerMethod() {
        System.out.println("Outer method called");

        // Create an instance of the inner class
        InnerClass inner = new InnerClass();
        inner.innerMethod();
    }

    // Define an inner class
    class InnerClass {
        public void innerMethod() {
            System.out.println("Inner method called");
            System.out.println("Outer int: " + outerInt);
        }
    }

    public static void main(String[] args) {
        // Create an instance of the outer class
        OuterClass outer = new OuterClass();

        // Call methods of the outer class
        outer.outerMethod();
    }
}
