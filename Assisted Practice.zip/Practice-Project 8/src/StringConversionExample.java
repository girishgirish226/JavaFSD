
public class StringConversionExample {

	public static void main(String[] args) {
		String str = "Girish, waykole";
        StringBuffer buffer = new StringBuffer(str);
        buffer.append(" This is a StringBuffer.");
        System.out.println("StringBuffer: " + buffer);
        StringBuilder builder = new StringBuilder(str);
        builder.append(" This is a StringBuilder.");
        System.out.println("StringBuilder: " + builder);

	}

}
