package arrays;

public class ArrayDemo {

	public static void main(String[] args) {
		 int[] numbers = {1, 2, 3, 4, 5};
	      
	      System.out.println("The elements of the array are:");
	      for (int i = 0; i < numbers.length; i++) {
	         System.out.print(numbers[i] + " ");
	      }
	      
	      String[] names = {"Girish", "Kishor", "Madhavi", "Yuva"};
	     
	      System.out.println("\nThe elements of the array are:");
	      for (int i = 0; i < names.length; i++) {
	         System.out.print(names[i] + " ");
	      }
	      
	      double[] prices = null;
	      
	      prices = new double[5];
	      prices[0] = 1.99;
	      prices[1] = 2.99;
	      prices[2] = 3.99;
	      prices[3] = 4.99;
	      prices[4] = 5.99;
	      
	      System.out.println("\nThe elements of the array are:");
	      for (int i = 0; i < prices.length; i++) {
	         System.out.print(prices[i] + " ");
	      }

	}

}
