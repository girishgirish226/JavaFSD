export class Admin {
    aId: number;
    uName: string;
    pass: string;
}
