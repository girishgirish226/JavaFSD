package com.ecommerce;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
