package com.test.example;

public class productRepository {

}
