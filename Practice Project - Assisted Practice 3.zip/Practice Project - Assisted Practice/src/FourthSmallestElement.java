import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FourthSmallestElement {

    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        list.add(9);
        list.add(4);
        list.add(2);
        list.add(7);
        list.add(5);
        list.add(1);

        int fourthSmallest = findFourthSmallestElement(list);
        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }

    private static int findFourthSmallestElement(List<Integer> list) {
        if (list.size() < 4) {
            throw new IllegalArgumentException("List should have at least four elements.");
        }

        Collections.sort(list);
        return list.get(3);
    }
}
