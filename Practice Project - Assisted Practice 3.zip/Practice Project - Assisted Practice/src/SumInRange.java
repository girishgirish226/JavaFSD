import java.util.Scanner;

public class SumInRange {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
		
			System.out.print("Enter the number of elements: ");
			int n = scanner.nextInt();

			System.out.print("Enter the value of L (0 <= L <= n-1): ");
			int L = scanner.nextInt();

			System.out.print("Enter the value of R (L <= R <= n-1): ");
			int R = scanner.nextInt();

			if (L < 0 || L >= n || R < L || R >= n) {
			    System.out.println("Invalid range!");
			    return;
			}

			int sum = calculateSum(n, L, R);
			System.out.println("Sum of elements in the range of L and R: " + sum);
		}
    }

    private static int calculateSum(int n, int L, int R) {
        int sum = 0;

        for (int i = L; i <= R; i++) {
            sum += i;
        }

        return sum;
    }
}
