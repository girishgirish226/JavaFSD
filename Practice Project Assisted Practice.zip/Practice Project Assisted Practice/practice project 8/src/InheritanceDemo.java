
class Animal {
    String type;
    
    public Animal(String type) {
        this.type = type;
    }
    
    public void move() {
        System.out.println(type + " is moving.");
    }
}

class Bird extends Animal {
    public Bird() {
        super("Bird");
    }
    
    public void fly() {
        System.out.println(type + " is flying.");
    }
}

public class InheritanceDemo {
    public static void main(String[] args) {
        Bird bird = new Bird();
        bird.move();
        bird.fly();
    }
}
