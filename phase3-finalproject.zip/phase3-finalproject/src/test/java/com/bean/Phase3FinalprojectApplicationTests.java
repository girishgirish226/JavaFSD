package com.bean;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Phase3FinalprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
